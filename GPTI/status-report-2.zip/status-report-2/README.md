# Status Report 2 — Fio a Fio — leia antes

Esta pasta contém o **Status Report 2** da disciplina de GPTI, com data de status 02/11/2026 e entrega em 09/11/2026. Ele mede o projeto contra a linha de base da AV1: cronograma, valor agregado e recursos.

| Arquivo | O que é |
|---|---|
| [`status-report-2.md`](status-report-2.md) | O relatório completo: escopo, cronograma, caminho crítico, valor agregado, índices, previsão, recursos, questões, mudanças, decisões e próximas ações. |
| `README.md` (este arquivo) | Como as horas foram obtidas e o que está em validação com a PSW. |
| [`../status-report-1/apontamento-de-horas.csv`](../status-report-1/apontamento-de-horas.csv) | **A planilha combinada no Status Report 1**, a fonte das horas, com as linhas da PSW e da GPTI. Fica na pasta do SR1 porque foi lá que o apontamento foi combinado. |
| [`apontamento-de-horas-gpti.csv`](apontamento-de-horas-gpti.csv) | Extrato só com as linhas da GPTI, idênticas às da planilha combinada, para facilitar a leitura. |

---

## Como as horas foram obtidas

### O método combinado não foi seguido

No Status Report 1 (26/10), GPTI e PSW combinaram que **cada aluno informaria as próprias horas** por atividade do cronograma (D01 a D18 e G01 a G12) e por semana. As semanas 1 a 8 seriam lançadas numa reunião de apontamento de 15 minutos, conduzida por **Matheus e Letícia** (plano, seção 7.4).

**Esse método não foi seguido.** A reunião não aconteceu, e **nenhum dos dois grupos apontou horas semana a semana**. O relatório registra isso como questão (Q-18), com Matheus e Letícia como donos.

### PSW: 68 h reconstituídas pela GPTI, em validação com a PSW

- **Quem chegou ao número:** a **GPTI reconstituiu** as horas da PSW em 02/11/2026, a partir do que está no repositório (commit `9e857eb`, de 06/10/2026). As horas **não foram informadas pela PSW**. Os valores estão **em validação com a Letícia e a Maria Clara**, num processo de acompanhamento contínuo, e qualquer ajuste entra no Status Report 3.
- **Por que a PSW não informou horas:**
  - **Semanas 1 a 8:** houve desenvolvimento, mas nenhuma hora foi informada.
  - **Semanas 9 e 10:** não houve desenvolvimento, e por isso não há horas a informar. As linhas de 0 h dessas semanas foram lançadas pela GPTI.
- **O que não foi feito não recebe hora.** Banco de dados, backend em Express, APIs próprias e integrações do M2 (D11 a D18) têm 0 h gasta, e esse trabalho continua inteiro como esforço restante.
- **Kauã:** 0 h. Não há nenhum commit dele nem retorno de contato.

### De onde vem cada valor da PSW

A reconstituição teve duas versões, e as duas aparecem no relatório (seção 8.3):

1. **Primeira versão: 97,5 h**, com as referências de esforço do próprio plano (seção 6.2.1): 11 h por cadastro de tela, 6 h para catálogo e detalhe, 10 h para compra, pagamento e estante, 6 h para avaliação e vendas, 3 h por item de base técnica e 10 h para trocar os dados simulados por uma API.
2. **Segunda versão: 68 h**, com referências revisadas para baixo: 4 h, 3 h, 3 h, 3 h, 1 h e 10 h, respectivamente. **É o CR usado no relatório.**

**A revisão não é mudança de linha de base.** O orçamento (ONT) e o valor planejado (VP) não mudam. As referências do plano estimam um pacote inteiro, com aceite. As revisadas estimam o que se observa entregue, que na maior parte não passou no aceite. A escolha muda o índice de custo da PSW (IDC 0,55 com 97,5 h; 0,78 com 68 h). Por isso o relatório mostra os dois. **A conclusão sobre capacidade é a mesma nos dois casos.**

A tabela abaixo mostra, para cada atividade, a conta pela referência revisada e o valor adotado. **Onde os dois diferem, a diferença está à vista e faz parte da validação com a PSW.**

| Atividade | O que se observa no repositório | Conta pela referência revisada | **Valor adotado** |
|---|---|---:|---:|
| D01 — escopo, atores e casos de uso | `DocumentacaoFioAFio.md` (30 casos de uso e 7 entidades) | sem referência revisada | 6 h |
| D02 — navegação e protótipos de tela | Protótipo de telas e navegação em React | sem referência revisada | 6 h |
| D03 — modelo de dados, mocks, cadastro e login simulados | 9 módulos em `src/mocks`, login e cadastro, edição de perfil | 1 + 1 + 0,5 = 2,5 h | 5 h |
| D04 — regras em JavaScript | Só a divisão 85/15 no checkout, com erro de soma | 13,5 × 1/4 = 3,4 h (pelo planejado) | 2 h |
| D05 — base React, rotas, identidade visual e componentes | Vite, Router, Tailwind, logo e componentes | 2 × 1 = 2 h | 5 h |
| D06 — publicações | Criar, consultar, curtir e comentar (4 de 6 operações) | 4 × 4/6 = 2,7 h | 3 h |
| D07 — vídeo-aulas da criadora | Cadastrar, consultar e editar (3 de 5 itens) | 4 × 3/5 = 2,4 h | 3 h |
| D08 — materiais | Lista e detalhe (1 de 4 itens) | 4 × 1/4 = 1 h | 3 h |
| D09 — catálogo, compra, pagamento, estante, avaliação e vendas | Telas do fluxo de compra, com aceites parciais | 3 + 1,9 + 0,5 + 1,5 = 6,9 h | 10 h |
| D10 — testes, correções e demonstração do M1 | **Sem teste e sem registro de demonstração.** O commit de 06/10 é a integração do JSON Server (MUD-01). | sem saída verificável | 2,5 h (classificação em validação: D10 ou MUD-01) |
| **Subtotal no escopo** |  |  | **45,5 h** |
| MUD-01 — JSON Server | Pasta `backend/`, `services/api.js`, troca da fonte de dados | 10 h | 8 h |
| MUD-02 — administração e moderação | 7 telas de administração | conta da primeira versão | 6,5 h |
| MUD-03 — chat | Tela e contextos de chat | idem | 3,5 h |
| MUD-04 — stories | Criação e exibição de stories | idem | 3,5 h |
| MUD-05 — pesquisa ampla e seguir | Tela de pesquisa | idem | 1 h |
| **Subtotal fora do escopo** (conta como gasto, não gera valor) |  |  | **22,5 h** |
| Semanas 9 e 10 (13/10 a 27/10) | Nenhum commit; linhas de 0 h lançadas pela GPTI | 0 h | 0 h |
| **Total** |  |  | **68 h** |

**Divisão por pessoa: premissa.** As 68 h estão divididas em partes iguais, 34 h para a Letícia e 34 h para a Maria Clara, porque a PSW não informou quem fez cada atividade. A planilha usa a janela do plano como semana, pelo mesmo motivo. **Essa divisão não prova nada sobre a carga real de cada uma.** É o primeiro ponto da validação.

**Esforço restante indicado pela PSW:** 20 h, para passar nos critérios de aceite pendentes até 10/11. O número tem duas limitações:

1. não vem por atividade;
2. coincide exatamente com o teto de capacidade da dupla (2 × 5 h × 2 semanas = 20 h).

Por isso o relatório não o usa como previsão.

### GPTI: horas registradas por atividade e conferidas

As horas da GPTI foram **registradas por atividade depois do fato e conferidas pelos integrantes**. Cada um lançou as horas de cada atividade G01 a G10 e conferiu as próprias linhas. **Não houve anotação semana a semana desde a semana 4**; a semana de cada linha é a da atividade no plano. G05, G09 e G10 foram registradas a partir do plano e da referência pelo entregável:

- **G05:** o planejado, 4 h;
- **G09:** 6 h de status mais 2 h do roteiro de verificação;
- **G10:** metade da referência de status, até 02/11.

| Pessoa | Semanas 4 a 9 (medidas) | G10, semana 10 em curso (fora da medição) | Total registrado |
|---|---:|---:|---:|
| Matheus | 20,33 h (G01 6; G04 3; G06 3,33; G07 3,33; G08 2; G09 2,67) | 1 h | 21,33 h |
| Gabriel | 20,33 h (G02 6; G04 3; G06 3,33; G07 3,33; G08 2; G09 2,67) | 1 h | 21,33 h |
| Guilherme | 21,33 h (G03 6; G05 4; G06 3,33; G07 3,33; G08 2; G09 2,67) | 1 h | 22,33 h |
| **Total** | **62 h** | **3 h** | **65 h** |

As 3 h de G10 ficam fora do valor agregado deste relatório, porque a semana 10 da GPTI ainda está em curso (fecha em 09/11). Entram no SR3.

---

## O que não depende das horas

Pelo plano, faltam **108,75 h** de trabalho da PSW. Esse número é o orçamento (162 h) menos o valor agregado (53,25 h). **Não é estimativa de ninguém**, só o que o plano diz que falta.

**Duas grandezas de 18 h, que não devem ser confundidas:**

| Grandeza | Conta | Valor |
|---|---|---:|
| Capacidade nominal da PSW até o M2 (10/11) | 2 alunas × 4,5 h × 2 semanas | 18 h (teto: 20 h) |
| Capacidade efetiva, se a semana 11 (que fecha em 03/11) não for usada | 2 alunas × 4,5 h × 1 semana | 9 h |
| Contingência de programação da PSW, no plano | 0,5 h × 3 alunos × 12 semanas | 18 h |
| Contingência de programação restante | 0,5 h × 2 alunas × 2 semanas | 2 h |

Como 108,75 h não cabem em 18 h, o relatório leva ao professor uma decisão de escopo (DEC-5).

---

## Em validação com a PSW (acompanhamento contínuo)

| Pendência | Quem | Prazo |
|---|---|---|
| Dizer **quem fez** cada atividade e **em que semana** (hoje a divisão é 50/50 e a semana é a do plano) | Letícia e Maria Clara | 06/11 |
| Confirmar ou corrigir o **valor de cada atividade**, sobretudo onde ele difere da conta pela referência (D03, D05, D08 e D09) | Letícia e Maria Clara | 06/11 |
| Dizer onde ficam as **2,5 h de D10**: em D10 ou na integração do JSON Server (MUD-01) | Letícia e Maria Clara | 06/11 |
| Distribuir as **20 h restantes** pelas atividades e dizer o que entregam até 10/11 | Letícia e Maria Clara | 06/11 |
| Lançar as horas **toda semana** na planilha combinada, a partir de 03/11 | PSW e GPTI, com conferência de Matheus e Letícia | Semanal |
